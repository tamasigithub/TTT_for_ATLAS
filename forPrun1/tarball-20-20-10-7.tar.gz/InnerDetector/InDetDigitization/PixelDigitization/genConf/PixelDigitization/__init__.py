## Hook for PixelDigitization genConf module
