#--------------------------------------------------------------
# SLHC setup
#--------------------------------------------------------------

# set the path variables consistently
from InDetSLHC_Example.SLHC_Setup_Alpine import SLHC_Setup_XMLReader
SLHC_Setup_XMLReader = SLHC_Setup_XMLReader()
