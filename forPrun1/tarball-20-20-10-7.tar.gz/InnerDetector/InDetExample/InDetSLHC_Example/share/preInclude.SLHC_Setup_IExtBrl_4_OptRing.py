#--------------------------------------------------------------
# SLHC setup
#--------------------------------------------------------------

# set the path variables consistently
from InDetSLHC_Example.SLHC_Setup_IExtBrl_4_OptRing import SLHC_Setup_XMLReader
SLHC_Setup_XMLReader = SLHC_Setup_XMLReader()
