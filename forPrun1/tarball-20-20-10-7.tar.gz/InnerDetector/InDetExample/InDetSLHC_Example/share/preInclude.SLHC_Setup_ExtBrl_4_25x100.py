#--------------------------------------------------------------
# SLHC setup
#--------------------------------------------------------------

# set the path variables consistently
from InDetSLHC_Example.SLHC_Setup_ExtBrl_4_25x100 import SLHC_Setup_XMLReader
SLHC_Setup_XMLReader = SLHC_Setup_XMLReader()
