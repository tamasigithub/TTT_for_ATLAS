include("InDetSLHC_Example/preInclude.SLHC.py")
include("InDetSLHC_Example/preInclude.SiliconOnly.py")
include("InDetSLHC_Example/preInclude.SLHC.Reco.py")

rec.doTrigger=False
rec.doCalo=False
rec.doJetMissingETTag=False
rec.doMuonCombined=False
rec.doEgamma=False
