#include "GaudiKernel/LoadFactoryEntries.h"

LOAD_FACTORY_ENTRIES( PixelDigitization )
LOAD_FACTORY_ENTRIES( ChargeCollProbSvc )
LOAD_FACTORY_ENTRIES( TimeSvc )
LOAD_FACTORY_ENTRIES( CalibSvc )
