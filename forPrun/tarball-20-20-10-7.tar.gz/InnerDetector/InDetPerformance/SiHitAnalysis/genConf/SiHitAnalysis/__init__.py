## Hook for SiHitAnalysis genConf module
