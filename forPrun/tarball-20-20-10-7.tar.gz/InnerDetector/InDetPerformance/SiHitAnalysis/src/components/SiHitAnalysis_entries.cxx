#include "SiHitAnalysis/SiHitAnalysis.h"
#include "GaudiKernel/DeclareFactoryEntries.h"
DECLARE_ALGORITHM_FACTORY(SiHitAnalysis)
DECLARE_FACTORY_ENTRIES(SiHitAnalysis) {
DECLARE_ALGORITHM(SiHitAnalysis)
}
