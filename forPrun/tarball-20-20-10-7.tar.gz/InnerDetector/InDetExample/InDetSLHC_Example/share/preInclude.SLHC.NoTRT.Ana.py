include("InDetSLHC_Example/preInclude.SLHC.NoTRT.Reco.py")

DetFlags.all_setOff()
DetFlags.dcs.all_setOn()
DetFlags.detdescr.all_setOn()
DetFlags.TRT_setOff()
DetFlags.BField_setOn()
