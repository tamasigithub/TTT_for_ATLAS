include("InDetSLHC_Example/preInclude.SLHC.py")
include("InDetSLHC_Example/preInclude.NoTRT.py")
include("InDetSLHC_Example/preInclude.SLHC.Reco.py")
