include("InDetSLHC_Example/preInclude.SLHC.SiliconOnly.Reco.py")

DetFlags.all_setOff()
DetFlags.dcs.all_setOn()
DetFlags.detdescr.all_setOn()
DetFlags.TRT_setOff()
DetFlags.Calo_setOff()
DetFlags.Muon_setOff()
DetFlags.BField_setOn()
