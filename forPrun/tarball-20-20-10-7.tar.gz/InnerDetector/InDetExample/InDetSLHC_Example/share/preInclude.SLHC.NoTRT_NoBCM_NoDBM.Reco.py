include("InDetSLHC_Example/preInclude.SLHC.py")
include("InDetSLHC_Example/preInclude.NoTRT_NoBCM_NoDBM.py")
include("InDetSLHC_Example/preInclude.SLHC.Reco.py")
