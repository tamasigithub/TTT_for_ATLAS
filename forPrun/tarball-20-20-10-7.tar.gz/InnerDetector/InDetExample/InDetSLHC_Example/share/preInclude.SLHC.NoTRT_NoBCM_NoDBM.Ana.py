include("InDetSLHC_Example/preInclude.SLHC.NoTRT_NoBCM_NoDBM.Reco.py")

DetFlags.all_setOff()
DetFlags.dcs.all_setOn()
DetFlags.detdescr.all_setOn()
DetFlags.TRT_setOff()
DetFlags.BCM_setOff()
DetFlags.DBM_setOff()
DetFlags.BField_setOn()
