# Temporary until BField tag for ATLAS-SLHC-01-00-00 put into COOL
from IOVDbSvc.CondDB import conddb
conddb.addOverride('/GLOBAL/BField/Map','BFieldMap-GEO-06-00-00')

