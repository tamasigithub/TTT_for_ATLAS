## Hook for InDetTrackingGeometryXML genConf module
