## Hook for PixelCabling genConf module
