## Hook for TripletTrackFinder genConf module
