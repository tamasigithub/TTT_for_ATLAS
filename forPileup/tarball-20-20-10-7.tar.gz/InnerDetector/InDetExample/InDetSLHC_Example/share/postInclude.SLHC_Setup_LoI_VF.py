#--------------------------------------------------------------
# SLHC setup
#--------------------------------------------------------------

# set the path variables consistently
from InDetSLHC_Example.SLHC_Setup_LoI_VF import SLHC_Setup
SLHC_Setup = SLHC_Setup()

include("InDetSLHC_Example/postInclude.SLHC_Setup_Common.py")
