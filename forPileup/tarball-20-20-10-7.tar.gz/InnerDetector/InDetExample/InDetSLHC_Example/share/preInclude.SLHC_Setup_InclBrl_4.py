#--------------------------------------------------------------
# SLHC setup
#--------------------------------------------------------------

# set the path variables consistently
from InDetSLHC_Example.SLHC_Setup_InclBrl_4 import SLHC_Setup_XMLReader
SLHC_Setup_XMLReader = SLHC_Setup_XMLReader()
