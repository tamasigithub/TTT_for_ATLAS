#include("InDetSLHC_Example/preInclude.OverrideBFieldTag.py")
#removed since BField should now be in conditions

# SLHC Flags -----------------------------------------------------
from InDetSLHC_Example.SLHC_JobProperties import SLHC_Flags
#SLHC_Flags.SLHC_Version = 'SLHC-23-24-dev12'
#SLHC_Flags.SLHC_Version = 'SLHC-23-25-dev2'
SLHC_Flags.SLHC_Version = ''
