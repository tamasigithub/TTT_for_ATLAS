from AthenaCommon.CfgGetter import addService
addService("PixelCabling.PixelCablingConfig.getPixelCablingSvc", "PixelCablingSvc")
